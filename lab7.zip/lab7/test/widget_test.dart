import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:lab7/main.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  Future<SharedPreferences> startApp(
    WidgetTester tester, [
    List<Note> notes = const [],
  ]) async {
    SharedPreferences.setMockInitialValues({
      'notes': notes.map((note) => jsonEncode(note.toJson())).toList(),
    });
    final preferences = await SharedPreferences.getInstance();
    await tester.pumpWidget(MainApp(preferences: preferences));
    return preferences;
  }

  Future<void> restartApp(
    WidgetTester tester,
    SharedPreferences preferences,
  ) async {
    // Rebuild the preferences cache, provider, and widgets from saved values.
    final savedNotes = List<String>.from(preferences.getStringList('notes')!);
    await tester.pumpWidget(const SizedBox.shrink());
    SharedPreferences.setMockInitialValues({'notes': savedNotes});
    final restored = await SharedPreferences.getInstance();
    await tester.pumpWidget(MainApp(preferences: restored));
    await tester.pumpAndSettle();
  }

  testWidgets('adds a note and restores it from saved data', (tester) async {
    final preferences = await startApp(tester);
    expect(find.text('No notes yet. Tap + to add one!'), findsOneWidget);
    await tester.tap(find.byTooltip('Add note'));
    await tester.pumpAndSettle();
    await tester.enterText(find.byType(TextFormField).at(0), 'Homework');
    await tester.enterText(find.byType(TextFormField).at(1), 'Finish Lab 7');
    await tester.tap(find.text('Save Note'));
    await tester.pumpAndSettle();
    expect(find.text('Homework'), findsOneWidget);
    expect(preferences.getStringList('notes'), hasLength(1));
    await restartApp(tester, preferences);
    expect(find.text('Homework'), findsOneWidget);
    expect(find.text('Finish Lab 7'), findsOneWidget);
  });

  testWidgets(
    'pencil prefills and updates only the selected note after restart',
    (tester) async {
      final preferences = await startApp(tester, const [
        Note('Groceries', 'Buy milk'),
        Note('Homework', 'Finish Lab 7'),
      ]);
      expect(find.byIcon(Icons.edit), findsNWidgets(2));
      expect(find.byIcon(Icons.delete), findsNWidgets(2));
      await tester.tap(find.byTooltip('Edit note').last);
      await tester.pumpAndSettle();
      expect(find.text('Edit Note'), findsOneWidget);
      expect(
        tester
            .widget<TextFormField>(find.byType(TextFormField).at(0))
            .controller!
            .text,
        'Homework',
      );
      expect(
        tester
            .widget<TextFormField>(find.byType(TextFormField).at(1))
            .controller!
            .text,
        'Finish Lab 7',
      );
      await tester.enterText(
        find.byType(TextFormField).at(0),
        'Updated homework',
      );
      await tester.enterText(find.byType(TextFormField).at(1), 'Submit Lab 7');
      await tester.tap(find.text('Save Note'));
      await tester.pumpAndSettle();
      expect(find.text('Updated homework'), findsOneWidget);
      expect(find.text('Homework'), findsNothing);
      expect(find.byType(ListTile), findsNWidgets(2));
      await restartApp(tester, preferences);
      expect(find.text('Updated homework'), findsOneWidget);
      expect(find.text('Submit Lab 7'), findsOneWidget);
      expect(find.text('Groceries'), findsOneWidget);
      expect(find.text('Buy milk'), findsOneWidget);
      expect(find.byType(ListTile), findsNWidgets(2));
    },
  );

  testWidgets('Back discards edits and empty fields cannot be saved', (
    tester,
  ) async {
    final preferences = await startApp(tester, const [
      Note('Title', 'Description'),
    ]);
    final before = List<String>.from(preferences.getStringList('notes')!);
    await tester.tap(find.byTooltip('Edit note'));
    await tester.pumpAndSettle();
    await tester.enterText(find.byType(TextFormField).at(0), '   ');
    await tester.enterText(find.byType(TextFormField).at(1), '');
    await tester.tap(find.text('Save Note'));
    await tester.pumpAndSettle();
    expect(find.text('Please enter a title.'), findsOneWidget);
    expect(find.text('Please enter a description.'), findsOneWidget);
    expect(preferences.getStringList('notes'), before);
    await tester.enterText(find.byType(TextFormField).at(0), 'Unsaved');
    await tester.pageBack();
    await tester.pumpAndSettle();
    expect(find.text('Unsaved'), findsNothing);
    expect(find.text('Title'), findsOneWidget);
    expect(preferences.getStringList('notes'), before);
  });

  testWidgets('deletion persists and editing still selects the right note', (
    tester,
  ) async {
    final preferences = await startApp(tester, const [
      Note('First', 'Remove me'),
      Note('Second', 'Keep me'),
    ]);
    await tester.tap(find.byTooltip('Delete note').first);
    await tester.pumpAndSettle();
    expect(find.text('First'), findsNothing);
    await tester.tap(find.byTooltip('Edit note'));
    await tester.pumpAndSettle();
    await tester.enterText(find.byType(TextFormField).at(0), 'Second updated');
    await tester.tap(find.text('Save Note'));
    await tester.pumpAndSettle();
    await restartApp(tester, preferences);
    expect(find.text('First'), findsNothing);
    expect(find.text('Second updated'), findsOneWidget);
    expect(find.text('Keep me'), findsOneWidget);
    expect(find.byType(ListTile), findsOneWidget);
  });
}
