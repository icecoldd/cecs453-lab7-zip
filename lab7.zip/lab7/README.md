# lab7

CECS 453 Lab 7: create, edit, and delete notes. The pencil icon next to each
trash icon opens the note's existing title and description. Save Note replaces
that note and saves the list locally so it is restored on the next launch.

This project copies the Flutter project structure, Provider state management,
and SharedPreferences approach from the local lab5. That lab5 is a mortgage
calculator; the assignment's reference to a notes-based "Code Lab 5" appears
to refer to a different classroom example. All app code stays in lib/main.dart.

## Run

From this folder:

```sh
flutter pub get
flutter run -d macos
```

For a browser, use a fixed port so each launch uses the same local storage:

```sh
flutter run -d chrome --web-port=7357
```

## Check the assignment

1. Tap + and save two notes with different titles and descriptions.
2. Tap the pencil next to one note. Both fields should contain its saved text.
3. Change both fields and tap Save Note. There should still be two notes,
   including the updated note and the unchanged second note.
4. Fully close the app (stop the Flutter run), then run it again on the same
   device. Both notes and the changes should still appear.
5. Edit a note and go Back without saving. The original text should remain.
6. Delete a note, close the app, and reopen it. The deleted note should stay gone.

Notes are stored on the current device or browser profile. Uninstalling the app
or clearing its storage removes them.

## Automated checks

```sh
flutter analyze
flutter test
```

Widget tests cover adding, editing, cancelling, validation, deletion, and
restoring the app from saved data. They use mocked preferences; the manual
close-and-reopen steps above check real device storage.
