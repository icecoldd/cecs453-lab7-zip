import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Note {
  final String title;
  final String description;

  const Note(this.title, this.description);

  Map<String, String> toJson() => {'title': title, 'description': description};

  factory Note.fromJson(Map<String, dynamic> json) {
    return Note(json['title'] as String, json['description'] as String);
  }
}

// Keep notes and their saved copy together, like Lab 5's MortgageData.
class NoteData extends ChangeNotifier {
  final SharedPreferences preferences;
  List<Note> _notes = [];
  bool isSaving = false;

  List<Note> get notes => List.unmodifiable(_notes);

  NoteData(this.preferences) {
    final savedNotes = preferences.getStringList('notes') ?? [];
    _notes = savedNotes
        .map((text) => Note.fromJson(jsonDecode(text) as Map<String, dynamic>))
        .toList();
  }

  Future<void> saveNote(Note note, {int? index}) async {
    final updatedNotes = List<Note>.from(_notes);
    if (index == null) {
      updatedNotes.add(note);
    } else {
      // Replace this note instead of adding a second copy.
      updatedNotes[index] = note;
    }
    await _saveNotes(updatedNotes);
  }

  Future<void> deleteNote(int index) async {
    final updatedNotes = List<Note>.from(_notes);
    updatedNotes.removeAt(index);
    await _saveNotes(updatedNotes);
  }

  Future<void> _saveNotes(List<Note> updatedNotes) async {
    if (isSaving) throw StateError('A save is already in progress.');
    isSaving = true;
    notifyListeners();
    try {
      final saved = await preferences.setStringList(
        'notes',
        updatedNotes.map((note) => jsonEncode(note.toJson())).toList(),
      );
      if (!saved) throw StateError('Could not save the notes.');
      _notes = updatedNotes;
    } finally {
      isSaving = false;
      notifyListeners();
    }
  }
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Restore saved notes before showing the list.
  final preferences = await SharedPreferences.getInstance();
  runApp(MainApp(preferences: preferences));
}

class MainApp extends StatelessWidget {
  final SharedPreferences preferences;

  const MainApp({super.key, required this.preferences});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => NoteData(preferences),
      child: MaterialApp(
        title: 'Lab 7 Notes',
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
          scaffoldBackgroundColor: const Color(0xFFF4F6FA),
          appBarTheme: const AppBarTheme(
            backgroundColor: Colors.indigo,
            foregroundColor: Colors.white,
          ),
          elevatedButtonTheme: ElevatedButtonThemeData(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.indigo,
              foregroundColor: Colors.white,
            ),
          ),
        ),
        home: const NoteListScreen(),
      ),
    );
  }
}

class NoteListScreen extends StatelessWidget {
  const NoteListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final data = context.watch<NoteData>();
    return Scaffold(
      appBar: AppBar(title: const Text('Notes')),
      body: data.notes.isEmpty
          ? const Center(child: Text('No notes yet. Tap + to add one!'))
          : ListView.builder(
              padding: const EdgeInsets.all(8),
              itemCount: data.notes.length,
              itemBuilder: (context, index) {
                final note = data.notes[index];
                return Card(
                  child: ListTile(
                    title: Text(note.title),
                    subtitle: Text(note.description),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          tooltip: 'Edit note',
                          icon: const Icon(Icons.edit),
                          onPressed: data.isSaving
                              ? null
                              : () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) =>
                                        NoteEditorScreen(index: index),
                                  ),
                                ),
                        ),
                        IconButton(
                          tooltip: 'Delete note',
                          icon: const Icon(Icons.delete, color: Colors.red),
                          onPressed: data.isSaving
                              ? null
                              : () async {
                                  try {
                                    await data.deleteNote(index);
                                  } catch (_) {
                                    if (!context.mounted) return;
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(
                                        content: Text(
                                          'Could not delete the note. Try again.',
                                        ),
                                      ),
                                    );
                                  }
                                },
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        tooltip: 'Add note',
        onPressed: data.isSaving
            ? null
            : () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const NoteEditorScreen()),
              ),
        child: const Icon(Icons.add),
      ),
    );
  }
}

// The same form adds a new note or edits an existing one.
class NoteEditorScreen extends StatefulWidget {
  final int? index;

  const NoteEditorScreen({super.key, this.index});

  @override
  State<NoteEditorScreen> createState() => _NoteEditorScreenState();
}

class _NoteEditorScreenState extends State<NoteEditorScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _titleController;
  late final TextEditingController _descriptionController;

  @override
  void initState() {
    super.initState();
    final note = widget.index == null
        ? null
        : context.read<NoteData>().notes[widget.index!];
    _titleController = TextEditingController(text: note?.title ?? '');
    _descriptionController = TextEditingController(
      text: note?.description ?? '',
    );
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  Future<void> _saveNote() async {
    if (!_formKey.currentState!.validate()) return;
    final data = context.read<NoteData>();
    if (data.isSaving) return;
    try {
      await data.saveNote(
        Note(_titleController.text.trim(), _descriptionController.text.trim()),
        index: widget.index,
      );
      if (!mounted) return;
      Navigator.pop(context);
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not save the note. Try again.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final isSaving = context.watch<NoteData>().isSaving;
    return PopScope(
      canPop: !isSaving,
      child: Scaffold(
        appBar: AppBar(
          title: Text(widget.index == null ? 'Add Note' : 'Edit Note'),
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                TextFormField(
                  controller: _titleController,
                  enabled: !isSaving,
                  decoration: const InputDecoration(labelText: 'Title'),
                  validator: (value) => value == null || value.trim().isEmpty
                      ? 'Please enter a title.'
                      : null,
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _descriptionController,
                  enabled: !isSaving,
                  decoration: const InputDecoration(labelText: 'Description'),
                  minLines: 3,
                  maxLines: 5,
                  validator: (value) => value == null || value.trim().isEmpty
                      ? 'Please enter a description.'
                      : null,
                ),
                const SizedBox(height: 24),
                ElevatedButton(
                  onPressed: isSaving ? null : _saveNote,
                  child: Text(isSaving ? 'Saving...' : 'Save Note'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
